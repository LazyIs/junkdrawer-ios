import SwiftUI

@main
struct junkdrawer_iosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}